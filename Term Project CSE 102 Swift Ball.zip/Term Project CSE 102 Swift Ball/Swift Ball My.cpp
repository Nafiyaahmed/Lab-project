#include<stdio.h>
#include<math.h>
#include<time.h>
#include<stdlib.h>
//# include "iGraphics.h"
#include "Screen Generator.h"

/*
void iDraw()
{
	iClear();
    scr2im();



	return;
}
*/



int main()
{
	printf("So far, the code runs!!\n");
	for(int k=0;k<10;k++)
	{
		//k=min(++k,10);
		printf("%d ", k);
	}
	//printf("%d", (int)round(3.4999));
	return 0;
}
