Press right and left button to move the ball.
Green bar is your safe zone, whereas red bar is your danger zone.
As you progress, the game will get more and more difficult.

					BEST OF LUCK FOR YOU!! 
